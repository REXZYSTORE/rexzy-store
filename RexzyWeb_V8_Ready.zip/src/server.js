
const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 10000;
const ROOT = path.join(__dirname, "..");
const PUBLIC = path.join(ROOT, "public");
const DATA_DIR = path.join(ROOT, "data");
const UPLOAD_DIR = path.join(ROOT, "uploads");

fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const DB_FILE = path.join(DATA_DIR, "store.json");
const defaults = {
  users: {},
  orders: [],
  services: [
    { id: "svc1", name: "Paket Starter", price: 15000, desc: "Layanan digital paket awal." },
    { id: "svc2", name: "Paket Growth", price: 35000, desc: "Paket digital untuk kebutuhan rutin." },
    { id: "svc3", name: "Paket Pro", price: 75000, desc: "Paket digital dengan prioritas proses." }
  ]
};
if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, JSON.stringify(defaults, null, 2));

function db() {
  try { return JSON.parse(fs.readFileSync(DB_FILE, "utf8")); }
  catch { return defaults; }
}
function save(data) { fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2)); }

const upload = multer({
  dest: UPLOAD_DIR,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_, file, cb) => {
    const ok = ["image/jpeg","image/png","image/webp"].includes(file.mimetype);
    cb(ok ? null : new Error("Bukti harus JPG, PNG, atau WEBP."), ok);
  }
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(PUBLIC));

function userKey(email) { return String(email || "").trim().toLowerCase(); }
function isOwner(email) {
  const owners = String(process.env.OWNER_EMAILS || "")
    .split(",").map(s => s.trim().toLowerCase()).filter(Boolean);
  return owners.includes(userKey(email));
}
function safeUser(email) {
  const key = userKey(email);
  const data = db();
  if (!data.users[key]) {
    data.users[key] = { email: key, vip: false, createdAt: new Date().toISOString() };
    save(data);
  }
  return data.users[key];
}

app.get("/api/config", (req, res) => {
  res.json({
    storeName: process.env.STORE_NAME || "Rexzy Store",
    whatsapp: process.env.WHATSAPP_URL || "#",
    channel: process.env.CHANNEL_URL || "#"
  });
});

app.post("/api/login", (req, res) => {
  const email = userKey(req.body.email);
  if (!email || !email.includes("@")) return res.status(400).json({ error: "Email tidak valid." });
  const user = safeUser(email);
  res.json({ user: { ...user, owner: isOwner(email) } });
});

app.get("/api/services", (_, res) => res.json(db().services));

app.get("/api/orders", (req, res) => {
  const email = userKey(req.query.email);
  if (!email) return res.status(400).json({ error: "Email diperlukan." });
  const data = db();
  const list = isOwner(email) ? data.orders : data.orders.filter(o => o.email === email);
  res.json(list.sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt)));
});

app.post("/api/orders", upload.single("proof"), (req, res) => {
  const email = userKey(req.body.email);
  const serviceId = req.body.serviceId;
  const target = String(req.body.target || "").trim();
  if (!email || !serviceId || !target) return res.status(400).json({ error: "Data pesanan belum lengkap." });

  const data = db();
  const service = data.services.find(s => s.id === serviceId);
  if (!service) return res.status(404).json({ error: "Layanan tidak ditemukan." });

  const order = {
    id: "RX-" + Date.now().toString(36).toUpperCase(),
    email,
    serviceId,
    serviceName: service.name,
    price: service.price,
    target,
    note: String(req.body.note || "").trim(),
    proof: req.file ? "/uploads/" + req.file.filename : null,
    status: req.file ? "Menunggu verifikasi" : "Menunggu bukti transfer",
    createdAt: new Date().toISOString()
  };
  data.orders.push(order);
  save(data);
  res.json(order);
});

app.use("/uploads", express.static(UPLOAD_DIR));

app.post("/api/admin/order-status", (req, res) => {
  const { email, secret, orderId, status } = req.body;
  if (!isOwner(email) || secret !== process.env.ADMIN_SECRET) return res.status(403).json({ error: "Akses admin ditolak." });
  const allowed = ["Menunggu bukti transfer", "Menunggu verifikasi", "Dibayar", "Diproses", "Selesai", "Ditolak"];
  if (!allowed.includes(status)) return res.status(400).json({ error: "Status tidak valid." });
  const data = db();
  const order = data.orders.find(o => o.id === orderId);
  if (!order) return res.status(404).json({ error: "Pesanan tidak ditemukan." });
  order.status = status;
  order.updatedAt = new Date().toISOString();
  save(data);
  res.json(order);
});

app.post("/api/admin/vip", (req, res) => {
  const { email, secret, memberEmail, vip } = req.body;
  if (!isOwner(email) || secret !== process.env.ADMIN_SECRET) return res.status(403).json({ error: "Akses admin ditolak." });
  const key = userKey(memberEmail);
  if (!key) return res.status(400).json({ error: "Email member diperlukan." });
  const data = db();
  if (!data.users[key]) data.users[key] = { email: key, createdAt: new Date().toISOString() };
  data.users[key].vip = Boolean(vip);
  save(data);
  res.json(data.users[key]);
});

app.get("/api/admin/members", (req, res) => {
  if (!isOwner(req.query.email) || req.query.secret !== process.env.ADMIN_SECRET) return res.status(403).json({ error: "Akses admin ditolak." });
  res.json(Object.values(db().users));
});

app.use((err, req, res, next) => {
  if (err) return res.status(400).json({ error: err.message || "Terjadi kesalahan." });
  next();
});

app.listen(PORT, () => console.log(`Rexzy Web V8 running on port ${PORT}`));
