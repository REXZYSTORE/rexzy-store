# Rexzy Web V8 Ready

Web mobile-first untuk transaksi manual:
- Tidak ada top-up saldo.
- Member membuat pesanan langsung dari dashboard.
- Member mengunggah bukti transfer.
- Owner/admin memeriksa dan mengubah status pesanan.
- VIP dapat diaktifkan oleh admin.
- Ada tombol WhatsApp admin dan channel.
- Role owner ditentukan dari `OWNER_EMAILS`.

## Jalankan di Render
1. Upload seluruh isi folder ini ke GitHub (struktur folder jangan diubah).
2. Render → New → Web Service.
3. Hubungkan repository GitHub.
4. Build Command: `npm install`
5. Start Command: `npm start`
6. Tambahkan Environment Variables:
   - `OWNER_EMAILS`
   - `ADMIN_SECRET`
   - `WHATSAPP_URL`
   - `CHANNEL_URL`
   - `STORE_NAME`
7. Deploy.

Catatan: penyimpanan JSON dan upload lokal cocok untuk awal/testing server. Untuk produksi yang tahan restart, pindahkan database dan file upload ke storage/database eksternal.
